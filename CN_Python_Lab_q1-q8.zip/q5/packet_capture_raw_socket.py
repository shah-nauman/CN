# Q5: Packet Capturing Application Using Raw Sockets
# NOTE: Run with administrator/root privileges.
# ========================== SERVER/CAPTURE CODE ==========================
import socket

s = socket.socket(socket.AF_INET, socket.SOCK_RAW, socket.IPPROTO_IP)

print("Packet Capturing Started...")

while True:
    data, addr = s.recvfrom(65535)

    print("Source IP:", addr[0])
    print("Packet Size:", len(data))
    print("Packet Data:", data[:20].hex())
    print("--------------------")

# This question does not require a separate client.
